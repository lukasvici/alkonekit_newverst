const hr = {
    data() {
      return {
        products: ["Пиво жадетское", "Водка Мароша", "Водка океан"],
      }
    },
    methods:{
        test(){
            console.log("sdfa")
        }
    }
  }
Vue.createApp(hr).mount('#hr')
const menu = {
  data() {
    return {
      subcategory: ['<a href="#">1</a><a href="#">2</a><a href="#">1</a>','<a href="#">1</a><a href="#">2</a><a href="#">1</a><a href="#">1</a>','<a href="#">1</a><a href="#">2</a><a href="#">1</a>'],
      category: ["Вина","Пиво","Шампанское","Алкоголь", "Vape","Промтовары"]
    }
  },
    methods: {
        openSub(id) {
            let state = $('#sub_'+id).css('display');

            if(state === 'none')
            {
                $('#sub_'+id).show();
            } else {
                $('#sub_'+id).hide();
            }
        }
    }
}
Vue.createApp(menu).mount('#menu')
  