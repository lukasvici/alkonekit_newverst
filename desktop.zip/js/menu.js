function openSlideMenu () {
    document.getElementById("menu").style.right = 0;
    document.getElementById("_open").style.visibility = 'hidden';
}
function closeSlideMenu () {
    document.getElementById("menu").style.right = '';
    document.getElementById("_open").style.visibility = '';
}